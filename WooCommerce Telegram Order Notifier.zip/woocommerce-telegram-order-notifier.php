<?php
/**
 * Plugin Name: WooCommerce Telegram Order Notifier
 * Plugin URI: https://example.com/woocommerce-telegram-order-notifier
 * Description: Sends instant Telegram notifications when a new WooCommerce order is placed.
 * Version: 1.0.1
 * Author: Store Tools
 * Author URI: https://example.com
 * Text Domain: wc-telegram-order-notifier
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 9.0
 *
 * @package WCTelegramOrderNotifier
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WCTON_VERSION', '1.0.1' );
define( 'WCTON_OPTION_NAME', 'wcton_settings' );
define( 'WCTON_TEST_ERROR_TRANSIENT', 'wcton_last_test_error' );

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

/**
 * Main plugin class.
 */
final class WCTON_Telegram_Order_Notifier {
	/**
	 * Bootstrap plugin hooks.
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_menu', array( __CLASS__, 'add_settings_page' ) );
		add_action( 'admin_notices', array( __CLASS__, 'show_woocommerce_notice' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'add_plugin_action_links' ) );

		add_action( 'woocommerce_new_order', array( __CLASS__, 'send_new_order_notification' ), 20, 2 );
		add_action( 'admin_post_wcton_send_test', array( __CLASS__, 'send_test_notification' ) );
	}

	/**
	 * Register plugin options.
	 */
	public static function register_settings() {
		register_setting(
			'wcton_settings_group',
			WCTON_OPTION_NAME,
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => array(
					'bot_token'         => '',
					'chat_id'           => '',
					'enabled'           => 'yes',
					'include_address'   => 'yes',
					'include_order_url' => 'yes',
				),
			)
		);

		add_settings_section(
			'wcton_main_section',
			__( 'Telegram Connection', 'wc-telegram-order-notifier' ),
			array( __CLASS__, 'render_section_intro' ),
			'wcton-settings'
		);

		add_settings_field(
			'enabled',
			__( 'Notifications', 'wc-telegram-order-notifier' ),
			array( __CLASS__, 'render_enabled_field' ),
			'wcton-settings',
			'wcton_main_section'
		);

		add_settings_field(
			'bot_token',
			__( 'Bot Token', 'wc-telegram-order-notifier' ),
			array( __CLASS__, 'render_bot_token_field' ),
			'wcton-settings',
			'wcton_main_section'
		);

		add_settings_field(
			'chat_id',
			__( 'Telegram Chat ID', 'wc-telegram-order-notifier' ),
			array( __CLASS__, 'render_chat_id_field' ),
			'wcton-settings',
			'wcton_main_section'
		);

		add_settings_field(
			'include_address',
			__( 'Include Billing Address', 'wc-telegram-order-notifier' ),
			array( __CLASS__, 'render_include_address_field' ),
			'wcton-settings',
			'wcton_main_section'
		);

		add_settings_field(
			'include_order_url',
			__( 'Include Admin Order Link', 'wc-telegram-order-notifier' ),
			array( __CLASS__, 'render_include_order_url_field' ),
			'wcton-settings',
			'wcton_main_section'
		);
	}

	/**
	 * Sanitize submitted settings.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize_settings( $input ) {
		$input = is_array( $input ) ? $input : array();

		return array(
			'bot_token'         => isset( $input['bot_token'] ) ? sanitize_text_field( $input['bot_token'] ) : '',
			'chat_id'           => isset( $input['chat_id'] ) ? sanitize_text_field( $input['chat_id'] ) : '',
			'enabled'           => ! empty( $input['enabled'] ) ? 'yes' : 'no',
			'include_address'   => ! empty( $input['include_address'] ) ? 'yes' : 'no',
			'include_order_url' => ! empty( $input['include_order_url'] ) ? 'yes' : 'no',
		);
	}

	/**
	 * Add admin menu entry.
	 */
	public static function add_settings_page() {
		add_submenu_page(
			'woocommerce',
			__( 'Telegram Orders', 'wc-telegram-order-notifier' ),
			__( 'Telegram Orders', 'wc-telegram-order-notifier' ),
			'manage_woocommerce',
			'wcton-settings',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Add quick settings link on the Plugins screen.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public static function add_plugin_action_links( $links ) {
		$settings_url = admin_url( 'admin.php?page=wcton-settings' );
		array_unshift(
			$links,
			sprintf(
				'<a href="%s">%s</a>',
				esc_url( $settings_url ),
				esc_html__( 'Settings', 'wc-telegram-order-notifier' )
			)
		);

		return $links;
	}

	/**
	 * Render settings page.
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$test_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=wcton_send_test' ),
			'wcton_send_test'
		);
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'WooCommerce Telegram Order Notifier', 'wc-telegram-order-notifier' ); ?></h1>

			<?php if ( isset( $_GET['wcton_test'] ) ) : ?>
				<?php if ( 'success' === $_GET['wcton_test'] ) : ?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e( 'Test Telegram notification sent successfully.', 'wc-telegram-order-notifier' ); ?></p>
					</div>
				<?php else : ?>
					<?php $test_error = get_transient( WCTON_TEST_ERROR_TRANSIENT ); ?>
					<div class="notice notice-error is-dismissible">
						<p><?php esc_html_e( 'Test notification failed. Check your bot token, chat ID, and server connection.', 'wc-telegram-order-notifier' ); ?></p>
						<?php if ( $test_error ) : ?>
							<p><strong><?php esc_html_e( 'Telegram error:', 'wc-telegram-order-notifier' ); ?></strong> <?php echo esc_html( $test_error ); ?></p>
						<?php endif; ?>
						<p><?php esc_html_e( 'Tip: open your Telegram bot and press Start or send it any message before testing. If this is a group, add the bot to the group and use the group chat ID.', 'wc-telegram-order-notifier' ); ?></p>
					</div>
				<?php endif; ?>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php
				settings_fields( 'wcton_settings_group' );
				do_settings_sections( 'wcton-settings' );
				submit_button();
				?>
			</form>

			<p>
				<a class="button button-secondary" href="<?php echo esc_url( $test_url ); ?>">
					<?php esc_html_e( 'Send Test Notification', 'wc-telegram-order-notifier' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	/**
	 * Render settings section intro.
	 */
	public static function render_section_intro() {
		echo '<p>' . esc_html__( 'Create a Telegram bot with BotFather, paste the bot token and chat ID below, then save settings.', 'wc-telegram-order-notifier' ) . '</p>';
	}

	/**
	 * Render enabled field.
	 */
	public static function render_enabled_field() {
		$settings = self::get_settings();
		self::render_checkbox( 'enabled', __( 'Send notifications for new orders', 'wc-telegram-order-notifier' ), 'yes' === $settings['enabled'] );
	}

	/**
	 * Render bot token field.
	 */
	public static function render_bot_token_field() {
		$settings = self::get_settings();
		printf(
			'<input type="password" class="regular-text" name="%1$s[bot_token]" value="%2$s" autocomplete="off" placeholder="123456789:ABC..." />',
			esc_attr( WCTON_OPTION_NAME ),
			esc_attr( $settings['bot_token'] )
		);
		echo '<p class="description">' . esc_html__( 'Get this from @BotFather in Telegram.', 'wc-telegram-order-notifier' ) . '</p>';
	}

	/**
	 * Render chat ID field.
	 */
	public static function render_chat_id_field() {
		$settings = self::get_settings();
		printf(
			'<input type="text" class="regular-text" name="%1$s[chat_id]" value="%2$s" placeholder="123456789 or -1001234567890" />',
			esc_attr( WCTON_OPTION_NAME ),
			esc_attr( $settings['chat_id'] )
		);
		echo '<p class="description">' . esc_html__( 'Use your personal chat ID or a Telegram group/channel chat ID.', 'wc-telegram-order-notifier' ) . '</p>';
	}

	/**
	 * Render include address field.
	 */
	public static function render_include_address_field() {
		$settings = self::get_settings();
		self::render_checkbox( 'include_address', __( 'Add billing address to the Telegram message', 'wc-telegram-order-notifier' ), 'yes' === $settings['include_address'] );
	}

	/**
	 * Render include order URL field.
	 */
	public static function render_include_order_url_field() {
		$settings = self::get_settings();
		self::render_checkbox( 'include_order_url', __( 'Add clickable WooCommerce admin order link', 'wc-telegram-order-notifier' ), 'yes' === $settings['include_order_url'] );
	}

	/**
	 * Render checkbox helper.
	 *
	 * @param string $key Setting key.
	 * @param string $label Checkbox label.
	 * @param bool   $checked Checked state.
	 */
	private static function render_checkbox( $key, $label, $checked ) {
		printf(
			'<label><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s /> %4$s</label>',
			esc_attr( WCTON_OPTION_NAME ),
			esc_attr( $key ),
			checked( $checked, true, false ),
			esc_html( $label )
		);
	}

	/**
	 * Show a dependency notice if WooCommerce is inactive.
	 */
	public static function show_woocommerce_notice() {
		if ( class_exists( 'WooCommerce' ) || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-warning"><p>';
		esc_html_e( 'WooCommerce Telegram Order Notifier requires WooCommerce to be installed and active.', 'wc-telegram-order-notifier' );
		echo '</p></div>';
	}

	/**
	 * Send notification after a new WooCommerce order is created.
	 *
	 * @param int      $order_id Order ID.
	 * @param WC_Order $order Order object, passed by newer WooCommerce versions.
	 */
	public static function send_new_order_notification( $order_id, $order = null ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$settings = self::get_settings();
		if ( 'yes' !== $settings['enabled'] || empty( $settings['bot_token'] ) || empty( $settings['chat_id'] ) ) {
			return;
		}

		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$message = self::build_order_message( $order, $settings );
		$result  = self::send_telegram_message( $settings['bot_token'], $settings['chat_id'], $message );

		if ( is_wp_error( $result ) ) {
			$order->add_order_note(
				sprintf(
					/* translators: %s is the Telegram error message. */
					__( 'Telegram notification failed: %s', 'wc-telegram-order-notifier' ),
					$result->get_error_message()
				)
			);
			return;
		}

		$order->add_order_note( __( 'Telegram notification sent to store owner.', 'wc-telegram-order-notifier' ) );
	}

	/**
	 * Send a test notification from the settings page.
	 */
	public static function send_test_notification() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to send a test notification.', 'wc-telegram-order-notifier' ) );
		}

		check_admin_referer( 'wcton_send_test' );

		$settings = self::get_settings();
		$message  = "Test notification from WooCommerce Telegram Order Notifier.\n\nYour Telegram integration is connected.";
		$result   = self::send_telegram_message( $settings['bot_token'], $settings['chat_id'], $message );
		$status = is_wp_error( $result ) ? 'failed' : 'success';

		if ( is_wp_error( $result ) ) {
			set_transient( WCTON_TEST_ERROR_TRANSIENT, $result->get_error_message(), 10 * MINUTE_IN_SECONDS );
		} else {
			delete_transient( WCTON_TEST_ERROR_TRANSIENT );
		}

		wp_safe_redirect( add_query_arg( 'wcton_test', $status, admin_url( 'admin.php?page=wcton-settings' ) ) );
		exit;
	}

	/**
	 * Build Telegram message text for an order.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @param array    $settings Plugin settings.
	 * @return string
	 */
	private static function build_order_message( $order, $settings ) {
		$customer_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		$customer_name = $customer_name ? $customer_name : __( 'Guest customer', 'wc-telegram-order-notifier' );
		$phone         = $order->get_billing_phone() ? $order->get_billing_phone() : __( 'Not provided', 'wc-telegram-order-notifier' );
		$email         = $order->get_billing_email() ? $order->get_billing_email() : __( 'Not provided', 'wc-telegram-order-notifier' );
		$payment       = $order->get_payment_method_title() ? $order->get_payment_method_title() : __( 'Not provided', 'wc-telegram-order-notifier' );
		$currency      = $order->get_currency();

		$lines   = array();
		$lines[] = 'New WooCommerce Order';
		$lines[] = 'Order: #' . $order->get_order_number();
		$lines[] = 'Customer: ' . $customer_name;
		$lines[] = 'Phone: ' . $phone;
		$lines[] = 'Email: ' . $email;
		$lines[] = 'Payment: ' . $payment;
		$lines[] = '';
		$lines[] = 'Products:';

		foreach ( $order->get_items() as $item ) {
			$lines[] = '- ' . $item->get_name() . ' x ' . $item->get_quantity();
		}

		$lines[] = '';
		$lines[] = 'Total: ' . html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $currency ) ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
		$lines[] = 'Status: ' . wc_get_order_status_name( $order->get_status() );

		if ( 'yes' === $settings['include_address'] ) {
			$address = trim( wp_strip_all_tags( $order->get_formatted_billing_address() ) );
			if ( $address ) {
				$lines[] = '';
				$lines[] = 'Billing Address:';
				$lines[] = html_entity_decode( $address, ENT_QUOTES, get_bloginfo( 'charset' ) );
			}
		}

		if ( 'yes' === $settings['include_order_url'] ) {
			$lines[] = '';
			$lines[] = 'View order: ' . $order->get_edit_order_url();
		}

		return implode( "\n", $lines );
	}

	/**
	 * Send plain-text message through Telegram Bot API.
	 *
	 * @param string $bot_token Telegram bot token.
	 * @param string $chat_id Telegram chat ID.
	 * @param string $message Message body.
	 * @return array|WP_Error
	 */
	private static function send_telegram_message( $bot_token, $chat_id, $message ) {
		if ( empty( $bot_token ) || empty( $chat_id ) ) {
			return new WP_Error( 'wcton_missing_credentials', __( 'Bot token or chat ID is missing.', 'wc-telegram-order-notifier' ) );
		}

		$bot_token = trim( $bot_token );
		$chat_id   = trim( $chat_id );
		$api_url   = 'https://api.telegram.org/bot' . preg_replace( '/[^0-9A-Za-z:._-]/', '', $bot_token ) . '/sendMessage';

		$response = wp_remote_post(
			$api_url,
			array(
				'timeout' => 20,
				'body'    => array(
					'chat_id'                  => $chat_id,
					'text'                     => self::trim_telegram_message( $message ),
					'disable_web_page_preview' => true,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$raw_body    = wp_remote_retrieve_body( $response );
		$body        = json_decode( $raw_body, true );

		if ( 200 !== $status_code || empty( $body['ok'] ) ) {
			$description = isset( $body['description'] ) ? $body['description'] : wp_strip_all_tags( $raw_body );
			$description = $description ? $description : __( 'Unknown Telegram API error.', 'wc-telegram-order-notifier' );
			return new WP_Error( 'wcton_telegram_api_error', sanitize_text_field( $description ) );
		}

		return $body;
	}

	/**
	 * Telegram messages have a 4096 character limit.
	 *
	 * @param string $message Message body.
	 * @return string
	 */
	private static function trim_telegram_message( $message ) {
		if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
			return mb_strlen( $message ) > 4000 ? mb_substr( $message, 0, 3997 ) . '...' : $message;
		}

		return strlen( $message ) > 4000 ? substr( $message, 0, 3997 ) . '...' : $message;
	}

	/**
	 * Get settings with defaults.
	 *
	 * @return array
	 */
	private static function get_settings() {
		$defaults = array(
			'bot_token'         => '',
			'chat_id'           => '',
			'enabled'           => 'yes',
			'include_address'   => 'yes',
			'include_order_url' => 'yes',
		);

		return wp_parse_args( get_option( WCTON_OPTION_NAME, array() ), $defaults );
	}
}

WCTON_Telegram_Order_Notifier::init();
