<?php
/**
 * Uninstall cleanup for WooCommerce Telegram Order Notifier.
 *
 * @package WCTelegramOrderNotifier
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wcton_settings' );
